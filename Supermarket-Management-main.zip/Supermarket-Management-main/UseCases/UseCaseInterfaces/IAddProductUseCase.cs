﻿using CoreBusiness;

namespace UseCases
{
	public interface IAddProductUseCase
	{
		void Execute(Product product);
	}
}