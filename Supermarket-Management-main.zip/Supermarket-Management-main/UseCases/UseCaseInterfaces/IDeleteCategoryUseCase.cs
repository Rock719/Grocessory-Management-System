﻿namespace UseCases
{
	public interface IDeleteCategoryUseCase
	{
		void Delete(int categoryId);
	}
}