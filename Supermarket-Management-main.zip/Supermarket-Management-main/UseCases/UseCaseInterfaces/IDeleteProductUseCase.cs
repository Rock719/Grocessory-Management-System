﻿namespace UseCases
{
	public interface IDeleteProductUseCase
	{
		void Delete(int productId);
	}
}