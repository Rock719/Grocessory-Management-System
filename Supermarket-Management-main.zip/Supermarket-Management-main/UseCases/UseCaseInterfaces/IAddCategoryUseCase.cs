﻿using CoreBusiness;

namespace UseCases
{
	public interface IAddCategoryUseCase
	{
		void Execute(Category category);
	}
}