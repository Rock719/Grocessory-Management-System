﻿using CoreBusiness;

namespace UseCases
{
	public interface IEditProductUseCase
	{
		void Execute(Product product);
	}
}