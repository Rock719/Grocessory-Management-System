﻿using CoreBusiness;

namespace UseCases
{
	public interface IEditCategoryUseCase
	{
		void Execute(Category category);
	}
}